<!-- untuk contact -->
    <div id="contact">
        <div class="wrapper">
            <div class="footer">
                <div class="footer-section">
                    <h3><?php echo ambil_isi_info('1','judul')?></h3>
                    <?php echo ambil_isi_info('1','isi')?>
                </div>
                <div class="footer-section">
                    <h3><?php echo ambil_isi_info('2','judul')?></h3>
                    <?php echo ambil_isi_info('2','isi')?>
                </div>
                <div class="footer-section">
                    <h3><?php echo ambil_isi_info('3','judul')?></h3>
                    <?php echo ambil_isi_info('3','isi')?>
                </div>
                <div class="footer-section">
                    <h3><?php echo ambil_isi_info('4','judul')?></h3>
                    <?php echo ambil_isi_info('4','isi')?>
                </div>
            </div>
        </div>
    </div>

    <div id="copyright">
        <div class="wrapper">
         &copy;Copyright 2022.
         <H1><b>Xyean_</b></H1>.All
         Rights Reserved.
            </div>
        </div>


</body>
</html>
